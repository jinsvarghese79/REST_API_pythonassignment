
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
import json
from django.http import JsonResponse


@api_view(['POST'])
def total(numbers):
    try:
        my_total = 0
        numbers_list = json.loads(numbers.body)
        for num in numbers_list:
            my_total += num

        return JsonResponse("total:"+str(my_total), safe=False)
    except ValueError as e:
        return Response(e.args[0], status.HTTP_400_BAD_REQUEST)

